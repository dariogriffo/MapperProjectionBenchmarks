--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.3 (Debian 15.3-1.pgdg110+1)
-- Dumped by pg_dump version 15.3 (Debian 15.3-0+deb12u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE automapper;
--
-- Name: automapper; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE automapper WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE automapper OWNER TO postgres;

\connect automapper

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: addresses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.addresses (
    id uuid NOT NULL,
    first_line text NOT NULL,
    second_line text,
    post_code character varying(16) NOT NULL
);


ALTER TABLE public.addresses OWNER TO postgres;

--
-- Name: posts_summaries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.posts_summaries (
    id uuid NOT NULL,
    total_views bigint NOT NULL,
    total_likes bigint NOT NULL,
    total_comments_received bigint NOT NULL,
    total_minutes_watched bigint NOT NULL,
    videos_created integer NOT NULL,
    user_id uuid NOT NULL
);


ALTER TABLE public.posts_summaries OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    first_name character varying(64) NOT NULL,
    last_name character varying(64) NOT NULL,
    display_name character varying(128) NOT NULL,
    date_of_birth date NOT NULL,
    address_id uuid
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: addresses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.addresses (id, first_line, second_line, post_code) FROM stdin;
\.
COPY public.addresses (id, first_line, second_line, post_code) FROM '$$PATH$$/3334.dat';

--
-- Data for Name: posts_summaries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.posts_summaries (id, total_views, total_likes, total_comments_received, total_minutes_watched, videos_created, user_id) FROM stdin;
\.
COPY public.posts_summaries (id, total_views, total_likes, total_comments_received, total_minutes_watched, videos_created, user_id) FROM '$$PATH$$/3335.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, first_name, last_name, display_name, date_of_birth, address_id) FROM stdin;
\.
COPY public.users (id, first_name, last_name, display_name, date_of_birth, address_id) FROM '$$PATH$$/3333.dat';

--
-- Name: addresses addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.addresses
    ADD CONSTRAINT addresses_pkey PRIMARY KEY (id);


--
-- Name: posts_summaries posts_summary_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts_summaries
    ADD CONSTRAINT posts_summary_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users a_f_k; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT a_f_k FOREIGN KEY (address_id) REFERENCES public.addresses(id) NOT VALID;


--
-- Name: posts_summaries p_u; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts_summaries
    ADD CONSTRAINT p_u FOREIGN KEY (user_id) REFERENCES public.users(id) NOT VALID;


--
-- PostgreSQL database dump complete
--

